<html>
<head>
<title>sample</title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
<link rel="stylesheet" href="css/skeleton.css">
 <link rel="stylesheet" href="css/normalize.css">
</head>
<body>

<img src='http://kytheateneo.org/images/kythelogo@2x.png' 

style="
position:fixed;
top:3%;
left:43%;
width:14%;
height:10%;

">

<div id="header">
<h3>HEADER</h3>
</div>