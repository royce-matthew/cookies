<?php get_header(); ?>

        <h3>Body</h3>
        <p>Contents Here</p>
        <div class="circle" id="circle"></div>
      <div style="position:absolute; top:510%;"> &nbsp;	</div>


<script>
 header = document.getElementById("header");
report= function(e){
header.innerHTML="X: "+e.x+"Y: "+e.y;
}
 document.addEventListener('click',report);

</script>

<?php get_footer(); ?>