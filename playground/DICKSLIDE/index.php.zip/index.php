<html lang="en">
<head>
<script src="easeljs-0.7.0.min.js"></script>
  <title>The HTML5 Herald</title>

  <style>
  body{
  	background-color: #99ccff;
  }
  .pix{
  	background: black;
  	
  	border-radius: 20px;
  	position: absolute;
  	top: 200px;
  	left: 200px;
  	width:50px;
  	height: 50px;

  }
  .pix02{
    background: purple;
    
    border-radius: 20px;
    position: absolute;
    top: 300px;
    left: 300px;
    width:50px;
    height: 50px;

  }

  </style>
</head>

<body>






































<p type='text' id='report'></p>

<p type='text' id='otherreport'></p>

<div class='pix' id='box'>
	</div>
<div class= 'pix02 'id='box2'>1</div>










  


  <script >


  	var thingy = document.getElementById('shape');
  	var box = document.getElementById('box');
    var box2 = document.getElementById('box2');


  	var report = document.getElementById('report');
  	var oreport = document.getElementById('otherreport');





  	var a = function(e)
  	{
  		

  		console.log(e);
  		oreport.innerHTML='x:'+e.pageX+'     y:'+e.pageY;
  	};
    var movedown = function(abc){
      box.style.left=abc+20;
    };
    var moveup= function(abc){
      box.style.left=abc-20;

    };

function update(){
oreport.innerHTML=
  <?php
$username = "root";
$password = "root";
$hostname = "localhost"; 
//echo "hi";
//connection to the database
$dbhandle = mysql_connect($hostname, $username, $password) 
  or die("Unable to connect to MySQL");
echo "";
//select a database to work with
$selected = mysql_select_db("localgame",$dbhandle) 
  or die("");

//+++++++++++++++++++++++++++++++
  //+++++++++++++++
//  echo" hoi";
$result = mysql_query("SELECT * FROM `players` WHERE `p1` = 'john'");
while($row=mysql_fetch_array($result))
{ 
  echo $row[1];
}?>;
if(box2.style.background=="red"){
box2.style.background="blue";
}
else{box2.style.background="red";}









}



    var status =0;

var tick = function()
  	{


update();



     abc = parseInt(getComputedStyle(box).left);
ser = parseInt(getComputedStyle(box2).left);





      report.innerHTML=abc+" "+status;
     
      };


var b = function(e)
  	{
  		if (box.style.background=='black'){
  			box.style.background="";
  	}
  		else{
  		box.style.background='black';
  	}
  	};
	createjs.Ticker.addEventListener("tick", tick);
document.addEventListener("keypress", checkKeyPressed, false);
 
function checkKeyPressed(e) 
{
  console.log(e.charCode);
    if (e.charCode == "97") 
    {
        moveup(abc);
    }
if (e.charCode == "100") 
    {
        movedown(abc);
    }
}









  	document.addEventListener('click',a);
	box.addEventListener('click',b);

  </script>
</body>
</html>